let stars = [];
let lasers = [];
let enemyLasers = [];
let aliens = [];

let score = 0;
let lives = 3;

let playerX = 250;
let invincible = false;
let invincibleTimer = 0;
let invincibleDuration = 120;

let gameOver = false;
let gameWon = false;

let enemyShootTimer = 0;

function setup() {
  createCanvas(500, 500);
  angleMode(DEGREES);
  rectMode(CENTER);
  frameRate(60);

  // Create background stars
  for (let i = 0; i < 60; i++) {
    stars.push({
      x: random(width),
      y: random(height),
      size: random(1, 4)
    });
  }

  createAliens();

  // Function that returns a value
  let total = calculatePoints(15, 100);
  print("Total possible points: " + total);
}

// Create the alien formation
function createAliens() {
  aliens = [];

  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 5; col++) {
      aliens.push({
        x: 75 + col * 85,
        y: 135 + row * 75,
        row: row,
        alive: true
      });
    }
  }
}

function draw() {
  background(12, 10, 35);

  drawStars();
  drawHUD();

  if (!gameOver && !gameWon) {
    drawAliens();
    updatePlayer();
    updatePlayerLasers();

    // Check for victory before enemies attack
    checkVictory();

    if (!gameWon) {
      updateEnemyLasers();

      if (!gameOver) {
        enemyShooting();
        updateInvincibility();
      }
    }
  }

  if (gameOver) {
    drawEndScreen("GAME OVER", color(255, 70, 90));
  }

  if (gameWon) {
    drawEndScreen("YOU WIN!", color(0, 255, 150));
  }
}

// Draw background stars
function drawStars() {
  noStroke();
  fill(255);

  for (let i = 0; i < stars.length; i++) {
    circle(stars[i].x, stars[i].y, stars[i].size);
  }
}

// Display title, score, and lives
function drawHUD() {
  textAlign(CENTER);
  textStyle(BOLD);

  fill(0, 255, 200);
  textSize(30);
  text("SPACE INVADERS", 250, 45);

  fill(255);
  textSize(17);
  text("SCORE: " + score, 250, 75);

  fill(255, 80, 100);
  textAlign(LEFT);
  text("LIVES: " + lives, 20, 105);

  // Display invincibility status
  if (invincible && !gameOver) {
    fill(255, 220, 50);
    textAlign(RIGHT);
    textSize(13);
    text("RESPAWNING...", 480, 105);
  }

  fill(200);
  textAlign(CENTER);
  textSize(12);
  text(
    "MOVE MOUSE | SPACEBAR TO SHOOT",
    250,
    485
  );
}

// Draw all living aliens
function drawAliens() {
  for (let i = 0; i < aliens.length; i++) {
    if (aliens[i].alive) {

      // Different colors for each row
      if (aliens[i].row === 0) {
        fill(255, 80, 140);
      } else if (aliens[i].row === 1) {
        fill(80, 255, 150);
      } else {
        fill(100, 170, 255);
      }

      // Animate alien size and rotation
      let alienSize =
        0.9 + sin(frameCount * 2 + i * 20) * 0.1;

      let angle =
        sin(frameCount * 2 + i * 10) * 8;

      drawAlien(
        aliens[i].x,
        aliens[i].y,
        alienSize,
        angle
      );
    }
  }
}

// Custom alien drawing function
function drawAlien(x, y, size, angle) {
  push();

  translate(x, y);
  scale(size);
  rotate(angle);

  // Alien body
  rect(0, 0, 42, 30, 6);

  // Alien head
  ellipse(0, -15, 38, 30);

  // Alien eyes
  fill(15, 15, 40);
  ellipse(-10, -17, 8, 10);
  ellipse(10, -17, 8, 10);

  // Alien legs
  stroke(255);
  strokeWeight(3);
  line(-14, 15, -20, 25);
  line(14, 15, 20, 25);

  noStroke();
  pop();
}

// Draw and move player spaceship
function updatePlayer() {

  // Player can only move when not invincible
  if (!invincible) {
    playerX = constrain(mouseX, 25, 475);
  }

  // Blink while invincible
  if (invincible && frameCount % 12 < 6) {
    return;
  }

  push();
  translate(playerX, 440);

  noStroke();

  // Spaceship body
  fill(0, 255, 200);
  triangle(-25, 15, 0, -25, 25, 15);

  // Spaceship engine
  fill(255, 220, 50);
  rect(0, 20, 30, 10);

  pop();
}

// Move player lasers and detect alien hits
function updatePlayerLasers() {
  for (let i = lasers.length - 1; i >= 0; i--) {

    // Move laser upward
    lasers[i].y -= 8;

    fill(255, 255, 0);
    noStroke();
    rect(lasers[i].x, lasers[i].y, 5, 20);

    let hit = false;

    // Check collision with aliens
    for (let j = 0; j < aliens.length; j++) {
      if (aliens[j].alive) {

        let distance = dist(
          lasers[i].x,
          lasers[i].y,
          aliens[j].x,
          aliens[j].y
        );

        if (distance < 25) {
          aliens[j].alive = false;
          score += 100;

          print("Alien destroyed! Score: " + score);

          hit = true;
          break;
        }
      }
    }

    // Remove laser after hit or leaving screen
    if (hit || lasers[i].y < 0) {
      lasers.splice(i, 1);
    }
  }
}

// Aliens randomly fire lasers
function enemyShooting() {
  enemyShootTimer++;

  // Shoot approximately every 45 frames
  if (enemyShootTimer >= 45) {

    let livingAliens = [];

    for (let i = 0; i < aliens.length; i++) {
      if (aliens[i].alive) {
        livingAliens.push(aliens[i]);
      }
    }

    if (livingAliens.length > 0) {
      let shooter = random(livingAliens);

      enemyLasers.push({
        x: shooter.x,
        y: shooter.y + 20
      });
    }

    enemyShootTimer = 0;
  }
}

// Move enemy lasers and detect player hits
function updateEnemyLasers() {
  for (let i = enemyLasers.length - 1; i >= 0; i--) {

    // Move enemy laser downward
    enemyLasers[i].y += 5;

    fill(255, 50, 70);
    noStroke();

    rect(
      enemyLasers[i].x,
      enemyLasers[i].y,
      6,
      18
    );

    // Detect collision with player
    if (
      !invincible &&
      abs(enemyLasers[i].x - playerX) < 22 &&
      abs(enemyLasers[i].y - 440) < 22
    ) {
      playerHit();

      // playerHit may clear the laser array
      if (gameOver) {
        enemyLasers = [];
      }

      break;

    } else if (enemyLasers[i].y > height) {
      enemyLasers.splice(i, 1);
    }
  }
}

// Handle player damage
function playerHit() {
  lives--;

  print("Player hit! Lives remaining: " + lives);

  // Clear all lasers when hit
  lasers = [];
  enemyLasers = [];

  if (lives <= 0) {
    gameOver = true;
    print("GAME OVER!");
  } else {

    // Respawn at center
    playerX = 250;

    // Activate invincibility frames
    invincible = true;
    invincibleTimer = invincibleDuration;

    print("Player respawned! Invincibility active.");
  }
}

// Handle invincibility countdown
function updateInvincibility() {
  if (invincible) {

    invincibleTimer--;

    if (invincibleTimer <= 0) {
      invincible = false;
      invincibleTimer = 0;

      print("Invincibility ended! You can shoot again.");
    }
  }
}

// Check whether all aliens are destroyed
function checkVictory() {
  let remaining = 0;

  for (let i = 0; i < aliens.length; i++) {
    if (aliens[i].alive) {
      remaining++;
    }
  }

  if (remaining === 0) {
    gameWon = true;
    enemyLasers = [];

    print("YOU WIN! Final Score: " + score);
  }
}

// Draw game over or victory screen
function drawEndScreen(message, messageColor) {
  textAlign(CENTER);
  textStyle(BOLD);

  fill(messageColor);
  textSize(40);
  text(message, 250, 260);

  fill(255);
  textSize(20);
  text("FINAL SCORE: " + score, 250, 300);

  textSize(15);
  text("Press R to restart", 250, 340);
}

// Keyboard controls
function keyPressed() {

  // Shoot ONLY if alive and NOT invincible
  if (
    key === ' ' &&
    !gameOver &&
    !gameWon &&
    !invincible
  ) {
    lasers.push({
      x: playerX,
      y: 410
    });

    return false;
  }

  // Restart after game over or victory
  if (key === 'r' || key === 'R') {
    if (gameOver || gameWon) {
      restartGame();
    }
  }

  // Prevent spacebar scrolling during invincibility
  if (key === ' ') {
    return false;
  }
}

// Reset game to starting state
function restartGame() {
  score = 0;
  lives = 3;

  playerX = 250;
  invincible = false;
  invincibleTimer = 0;

  gameOver = false;
  gameWon = false;

  lasers = [];
  enemyLasers = [];

  enemyShootTimer = 0;

  createAliens();

  print("New game started!");
}

// Function that returns a value
function calculatePoints(enemies, pointsEach) {
  return enemies * pointsEach;
}
