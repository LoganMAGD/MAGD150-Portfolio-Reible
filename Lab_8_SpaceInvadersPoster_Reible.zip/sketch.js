let backgroundImage;
let alienImage;
let spaceshipImage;

// Load our three images
function preload() {
  backgroundImage = loadImage('starfield.png');
  alienImage = loadImage('alien.png');
  spaceshipImage = loadImage('spaceship.png');
}

function setup() {
  createCanvas(600, 600);
  imageMode(CENTER);
  textFont('Arial');
}

function draw() {

  // Draw the background
  image(backgroundImage, width / 2, height / 2, width, height);

  noStroke();
  fill(3, 7, 30, 120);
  rect(0, 0, width, height);

  // Arcade title
  textAlign(CENTER, CENTER);
  textFont('Arial');
  textStyle(BOLD);
  textSize(42);

  stroke(255, 55, 160);
  strokeWeight(4);
  fill(90, 250, 255);

  text('SPACE INVADERS', 45, 28, 510, 65);

  // Subtitle
  noStroke();
  fill(255, 225, 110);
  textSize(16);

  text('DEFEND THE GALAXY', 95, 104, 410, 35);

  // Change alien size using mouseX
  let alienSize = map(
    constrain(mouseX, 0, width),
    0, width, 52, 82
  );

  // Animate the aliens
  let sway = sin(frameCount * 0.035) * 13;

  for (let row = 0; row < 2; row++) {
    for (let col = 0; col < 5; col++) {

      let x = 112 + col * 94 + sway;
      let y = 215 + row * 95
            + sin(frameCount * 0.05 + col) * 5;

      image(
        alienImage,
        x,
        y,
        alienSize,
        alienSize * 0.8
      );
    }
  }

  // Decorative laser beams
  stroke(95, 255, 190, 180);
  strokeWeight(3);

  line(90, 435, 90, 455);
  line(510, 440, 510, 460);

  // Move the transparent spaceship with the mouse
  let shipX = constrain(mouseX, 55, width - 55);
  let shipY = constrain(mouseY, 405, height - 75);

  image(spaceshipImage, shipX, shipY, 105, 75);

  // Instructions at the bottom
  noStroke();
  fill(255);
  textStyle(NORMAL);
  textSize(15);

  text(
    'MOVE YOUR MOUSE TO PILOT THE SHIP',
    65, 554, 470, 35
  );
}
