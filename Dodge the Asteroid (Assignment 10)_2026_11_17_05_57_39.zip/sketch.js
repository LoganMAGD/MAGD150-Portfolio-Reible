
let player;
let asteroids = [];

let score = 0;
let lives = 3;
let gameOver = false;

// ------------------------------
// SETUP
// ------------------------------

function setup() {
  createCanvas(500, 600);

  // p5play feature 1: Sprite creation
  player = new Sprite(250, 530, 45, 35, "none");

  player.color = "cyan";
  player.text = "▲";
  player.textSize = 28;
}

// ------------------------------
// GAME LOOP
// ------------------------------

function draw() {
  background(10, 10, 35);

  // Display score and lives
  fill("white");
  textSize(20);
  textAlign(LEFT);

  text("Score: " + score, 15, 30);
  text("Lives: " + lives, 390, 30);

  // Check for game over
  if (gameOver) {
    drawGameOver();
    return;
  }

  movePlayer();

  // Spawn asteroids
  if (frameCount % 45 === 0) {
    spawnAsteroid();
  }

  updateAsteroids();
}

// ------------------------------
// PLAYER MOVEMENT
// ------------------------------

function movePlayer() {
  let speed = 6;

  if (keyIsDown(LEFT_ARROW) || keyIsDown(65)) {
    player.x -= speed;
  }

  if (keyIsDown(RIGHT_ARROW) || keyIsDown(68)) {
    player.x += speed;
  }

  // Keep player on screen
  player.x = constrain(player.x, 25, 475);
}

// ------------------------------
// CREATE ASTEROIDS
// ------------------------------

function spawnAsteroid() {
  let x = random(30, 470);

  // Create asteroid sprite
  let asteroid = new Sprite(x, -30, 35, "none");

  asteroid.color = "orange";

  // Give each asteroid its own speed
  asteroid.fallSpeed = random(3, 6);

  asteroids.push(asteroid);
}

// ------------------------------
// UPDATE ASTEROIDS
// ------------------------------

function updateAsteroids() {
  for (let i = asteroids.length - 1; i >= 0; i--) {
    let asteroid = asteroids[i];

    // Move asteroid downward
    asteroid.y += asteroid.fallSpeed;

    // p5play feature 2: Overlap detection
    if (player.overlaps(asteroid)) {
      lives--;

      // p5play feature 3: Delete sprite
      asteroid.delete();
      asteroids.splice(i, 1);

      if (lives <= 0) {
        gameOver = true;
      }
    }

    // Asteroid passed the player
    else if (asteroid.y > height + 30) {
      asteroid.delete();
      asteroids.splice(i, 1);

      score++;
    }
  }
}

// ------------------------------
// GAME OVER SCREEN
// ------------------------------

function drawGameOver() {
  player.visible = false;

  for (let asteroid of asteroids) {
    asteroid.visible = false;
  }

  fill("white");
  textAlign(CENTER);

  textSize(40);
  text("GAME OVER", width / 2, 280);

  textSize(20);
  text("Final Score: " + score, width / 2, 320);
}
